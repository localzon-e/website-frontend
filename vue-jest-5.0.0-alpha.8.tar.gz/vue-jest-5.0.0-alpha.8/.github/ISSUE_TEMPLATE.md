<!--
  If you are creating a bug report, please include a link to a runnable
  reproduction in a Git repository
-->
