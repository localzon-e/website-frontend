# vue-jest-next

Jest Vue transformer for Vue 3 with source map support (WIP).

Docs for current stable version (targeting Vue 2.x): https://github.com/vuejs/vue-jest/

## TODO (supported in vue-jest@4.x but not vue-jest@next):

- [ ] Support loading styles
- [ ] Support custom blocks
