<script>
export const randomExport = 42

export default {
  name: 'NamedExport'
}
</script>
