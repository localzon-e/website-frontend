<template lang="pug">
extends /components/PugBase.pug
block component
  div(class="pug-extended")
</template>

<script>
export default {
  name: 'pug'
}
</script>
