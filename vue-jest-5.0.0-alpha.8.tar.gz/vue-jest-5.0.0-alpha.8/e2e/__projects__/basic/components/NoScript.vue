<template>
  <footer class="footer">I'm footer!</footer>
</template>

<style>
.footer {
  padding: 15px;
  border: 1px dashed red;
  text-align: center;
  margin-top: 30px;
}
</style>
