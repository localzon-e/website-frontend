<template>
  <h1>CoffeeScript</h1>
</template>

<script lang="coffeescript">
export default
    data: -> {}
</script>
