module.exports = {
  presets: ['@babel/preset-env'],
  plugins: ['transform-vue-jsx']
}
