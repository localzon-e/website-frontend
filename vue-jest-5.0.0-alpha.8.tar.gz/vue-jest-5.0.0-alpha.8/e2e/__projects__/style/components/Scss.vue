<template>
  <div />
</template>

<style lang="scss" module>
@import '~__styles/scss-a';

.c {
  background-color: $primary-color;
}
</style>

<style lang="scss">
.d {
  background-color: red;
}
</style>

<style lang="scss" module themed>
.f {
  background-color: red;
}
</style>
