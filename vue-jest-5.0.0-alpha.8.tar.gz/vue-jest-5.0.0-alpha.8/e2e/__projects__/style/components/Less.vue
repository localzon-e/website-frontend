<template>
  <div />
</template>

<style module lang="less">
.a {
  background-color: @primary-color;
}
</style>
