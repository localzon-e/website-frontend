<template>
  <div />
</template>

<style module lang="sass">
@import "~__styles/sass-a"

.c
  background-color: red
</style>

<style lang="sass">
.d
  background-color: blue
</style>

<style lang="sass" module themed>
.e
  background-color: blue
</style>
