// import { createApp, h } from 'vue'

// import Scss from './components/Scss.vue'

// function mount(Component, props, slots) {
//   document.getElementsByTagName('html')[0].innerHTML = ''
//   const el = document.createElement('div')
//   el.id = 'app'
//   document.body.appendChild(el)
//   const Parent = {
//     render() {
//       return h(Component, props, slots)
//     }
//   }
//   createApp(Parent).mount(el)
// }

// TODO: Figure this out with Vue 3. `$style` no longer exists.
test.todo('processes SCSS using user specified post transforms')

test.todo('processes SCSS using user specified pre transforms')
